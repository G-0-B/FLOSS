use serde::{Serialize, Deserialize};
use hdk::prelude::*;
use std::collections::HashSet;

/// Represents the center of a cluster of vectors.
///
/// `Centroid`s are used in clustering algorithms to represent the mean position
/// of a set of data points. In the context of the ARF, they can be used to
/// summarize and navigate the semantic space of the knowledge graph.
///
/// TODO: Needs refinement by a human expert.
#[hdk_entry(id = "centroid")]
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Centroid {
    pub id: String,
    pub vector: Vec<f32>,
    pub level: u8,
    pub cluster_size: u32,
    pub responsible_agents: HashSet<AgentPubKey>,
    pub version: u64,
}

impl Centroid {
    /// Creates a new `Centroid`.
    ///
    /// TODO: Needs refinement by a human expert.
    pub fn new(vector: Vec<f32>, level: u8) -> Self {
        Self {
            id: nanoid::nanoid!(),
            vector,
            level,
            cluster_size: 0,
            responsible_agents: HashSet::new(),
            version: 0,
        }
    }

    /// Updates the centroid with a new vector.
    ///
    /// This method recalculates the centroid's position by taking a weighted
    /// average of its current position and the new vector.
    ///
    /// TODO: Needs refinement by a human expert.
    pub fn update(&mut self, vector: &[f32]) {
        let weight = 1.0 / (self.cluster_size + 1) as f32;
        for (c, v) in self.vector.iter_mut().zip(vector.iter()) {
            *c = *c * (1.0 - weight) + v * weight;
        }
        self.cluster_size += 1;
        self.version += 1;
    }
}