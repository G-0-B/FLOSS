//! The `core` module provides the fundamental data structures and metrics for the system.
//!
//! This includes vector and centroid representations, a CRDT for convergent
//! centroids, and a metrics collector.
//!
//! TODO: Needs refinement by a human expert.

// src/core/mod.rs
mod vector;
mod centroid;
mod metrics;
mod centroid_crdt;

pub use vector::Vector;
pub use centroid::Centroid;
pub use metrics::Metrics;
pub use centroid_crdt::{CentroidCRDT, VersionVector};
