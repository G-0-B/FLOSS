//! The `sharding` module provides utilities for data distribution and sharding.
//!
//! This includes a `ShardManager` for orchestrating the sharding process, a
//! `HilbertCurve` implementation for mapping multi-dimensional data to a
//! one-dimensional space, and a `MigrationPlan` for managing the movement of
//! data between shards.
//!
//! TODO: Needs refinement by a human expert.

mod hilbert;
mod manager;
mod migration;

pub use hilbert::HilbertCurve;
pub use manager::ShardManager;
pub use migration::MigrationPlan;
