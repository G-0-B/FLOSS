//! A library for a sharded, networked, and neural-like system.
//!
//! This crate provides the core components for a distributed system that
//! includes sharding, networking, and a "nerv" system for model updates.
//! It is a key part of the ARF's infrastructure for decentralized AI.
//!
//! TODO: Needs refinement by a human expert.

pub mod core;
pub mod sharding;
pub mod error;
pub mod network;
pub mod nerv;

pub use core::{Vector, Centroid, Metrics};
pub use sharding::{ShardManager, HilbertCurve};
pub use error::ShardError;
pub use network::{CircuitBreaker, RetryStrategy};
pub use nerv::{NervRuntime, ModelUpdate};
