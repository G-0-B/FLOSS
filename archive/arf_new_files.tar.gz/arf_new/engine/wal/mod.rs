// Write-Ahead Log for shard durability

use std::fs::{OpenOptions};
use std::io::{Write, Result};

pub struct Wal {
    file: std::fs::File,
}

impl Wal {
    pub fn open(path: &str) -> Result<Self> {
        let file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(path)?;
        Ok(Self { file })
    }

    pub fn append(&mut self, record: &str) -> Result<()> {
        writeln!(self.file, "{}", record)
    }
}
