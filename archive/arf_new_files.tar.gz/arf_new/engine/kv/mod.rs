// Simple key-value store stub for per-shard metadata

use std::collections::HashMap;

pub struct KvStore {
    inner: HashMap<String, Vec<u8>>,
}

impl KvStore {
    pub fn new() -> Self {
        Self { inner: HashMap::new() }
    }

    pub fn put(&mut self, key: &str, value: Vec<u8>) {
        self.inner.insert(key.to_string(), value);
    }

    pub fn get(&self, key: &str) -> Option<&Vec<u8>> {
        self.inner.get(key)
    }
}
