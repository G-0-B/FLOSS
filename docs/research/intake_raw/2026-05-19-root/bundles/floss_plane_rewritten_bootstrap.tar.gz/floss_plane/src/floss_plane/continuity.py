from __future__ import annotations
from .util import sha256_text, now_iso


def save_continuity(conn, perceptual_shift: str, trajectory_next: str, substrate_anchor: str | None = None) -> int:
    state_hash = sha256_text(perceptual_shift + trajectory_next + now_iso())
    cur = conn.execute(
        """
        INSERT INTO continuity_vectors(state_hash, perceptual_shift, trajectory_next, substrate_anchor, created_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (state_hash, perceptual_shift, trajectory_next, substrate_anchor, now_iso()),
    )
    conn.commit()
    return int(cur.lastrowid)


def latest_continuity(conn):
    return conn.execute("SELECT * FROM continuity_vectors ORDER BY id DESC LIMIT 1").fetchone()
