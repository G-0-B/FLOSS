from __future__ import annotations
from pathlib import Path
from .config import RAW
from .util import load_text
from .artifacts import register_artifact


def ingest_dir(conn, source_dir: Path) -> int:
    count = 0
    for file in source_dir.rglob("*"):
        if not file.is_file():
            continue
        text = load_text(file)
        target = RAW / file.name
        if not target.exists() or load_text(target) != text:
            target.write_text(text, encoding="utf-8")
        register_artifact(conn, target, "raw", text)
        count += 1
    return count
