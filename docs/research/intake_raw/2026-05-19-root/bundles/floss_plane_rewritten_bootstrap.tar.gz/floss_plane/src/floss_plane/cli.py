from __future__ import annotations

import argparse
import json
from pathlib import Path

from floss_plane.bootstrap import WorkspaceBootstrap


def main() -> None:
    parser = argparse.ArgumentParser(prog='floss-plane')
    sub = parser.add_subparsers(dest='cmd', required=True)
    for name in ('init', 'bootstrap-status', 'build-context', 'export-bootstrap', 'gateway-schema'):
        p = sub.add_parser(name)
        p.add_argument('--workspace', required=True)
    route = sub.add_parser('route')
    route.add_argument('--workspace', required=True)
    route.add_argument('--query', required=True)
    args = parser.parse_args()
    boot = WorkspaceBootstrap(Path(args.workspace))
    if args.cmd == 'init':
        print(json.dumps(boot.init_runtime(), indent=2))
    elif args.cmd == 'bootstrap-status':
        print(json.dumps(boot.load()['manifest'], indent=2))
    elif args.cmd == 'build-context':
        print(json.dumps(boot.build_context_views(), indent=2))
    elif args.cmd == 'export-bootstrap':
        out = boot.export_manifest(boot.load()['manifest'])
        print(json.dumps({'manifest_path': str(out)}, indent=2))
    elif args.cmd == 'gateway-schema':
        print(json.dumps(boot.gateway_schema(), indent=2))
    elif args.cmd == 'route':
        print(json.dumps(boot.route_query(args.query)[:5], indent=2))


if __name__ == '__main__':
    main()
