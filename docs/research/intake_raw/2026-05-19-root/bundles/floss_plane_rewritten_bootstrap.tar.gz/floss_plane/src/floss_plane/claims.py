from __future__ import annotations
from .models import Claim
from .util import now_iso


def add_claim(conn, claim: Claim) -> int:
    payload = claim.to_dict()
    payload["ingested_at"] = payload["ingested_at"] or now_iso()
    cur = conn.execute(
        """
        INSERT INTO claims(
            subject, predicate, object, source_ref, confidence, status,
            event_valid_from, event_valid_to, ingested_at, invalidated_at, supersedes_claim_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            payload["subject"], payload["predicate"], payload["object"], payload["source_ref"],
            payload["confidence"], payload["status"], payload["event_valid_from"], payload["event_valid_to"],
            payload["ingested_at"], payload["invalidated_at"], None,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def invalidate_claim(conn, claim_id: int, ts: str) -> None:
    conn.execute("UPDATE claims SET invalidated_at=?, status='superseded' WHERE id=?", (ts, claim_id))
    conn.commit()
