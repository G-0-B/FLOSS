from __future__ import annotations
import sqlite3
from .config import DB, RAW, PARSED, WIKI, GRAPH, RUNTIME, REPORTS, LEASES, QUEUES, REFLECTIONS, CONTINUITY


def ensure_dirs() -> None:
    for p in [RAW, PARSED, WIKI, GRAPH, RUNTIME, REPORTS, LEASES, QUEUES, REFLECTIONS, CONTINUITY]:
        p.mkdir(parents=True, exist_ok=True)


def connect() -> sqlite3.Connection:
    ensure_dirs()
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS artifacts (
            id INTEGER PRIMARY KEY,
            path TEXT UNIQUE,
            layer TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            parent_sha256 TEXT
        );

        CREATE TABLE IF NOT EXISTS claims (
            id INTEGER PRIMARY KEY,
            subject TEXT NOT NULL,
            predicate TEXT NOT NULL,
            object TEXT NOT NULL,
            source_ref TEXT NOT NULL,
            confidence REAL NOT NULL,
            status TEXT NOT NULL,
            event_valid_from TEXT,
            event_valid_to TEXT,
            ingested_at TEXT NOT NULL,
            invalidated_at TEXT,
            supersedes_claim_id INTEGER
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            status TEXT NOT NULL,
            capability TEXT,
            lease_owner TEXT,
            lease_expires_at TEXT,
            ru_cost REAL DEFAULT 0,
            blocked_by TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS continuity_vectors (
            id INTEGER PRIMARY KEY,
            state_hash TEXT NOT NULL,
            perceptual_shift TEXT NOT NULL,
            trajectory_next TEXT NOT NULL,
            substrate_anchor TEXT,
            created_at TEXT NOT NULL
        );
        """
    )
    return conn
