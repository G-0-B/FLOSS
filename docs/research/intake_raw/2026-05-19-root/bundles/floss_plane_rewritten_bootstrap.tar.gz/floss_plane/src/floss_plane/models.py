from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class Claim:
    subject: str
    predicate: str
    object: str
    source_ref: str
    confidence: float = 0.5
    status: str = "candidate"
    event_valid_from: Optional[str] = None
    event_valid_to: Optional[str] = None
    ingested_at: Optional[str] = None
    invalidated_at: Optional[str] = None

    def to_dict(self):
        return asdict(self)
