from __future__ import annotations
from .config import WIKI, REPORTS
from .util import load_text, now_iso, dump_json
from datetime import datetime


def run_lint() -> str:
    wiki_files = sorted(WIKI.glob("*.md"))
    names = {f.stem for f in wiki_files}
    orphans = []
    thin = []
    broken_links = []
    for file in wiki_files:
        text = load_text(file)
        body = [line for line in text.splitlines() if line.strip() and not line.strip().startswith("---")]
        if len(body) < 4 and file.stem != "index":
            thin.append(file.stem)
        inbound = sum(1 for other in wiki_files if other != file and f"[[{file.stem}]]" in load_text(other))
        if inbound == 0 and file.stem != "index":
            orphans.append(file.stem)
        for token in [part.split("]]",1)[0] for part in text.split("[[")[1:]]:
            if token not in names:
                broken_links.append({"from": file.stem, "to": token})
    payload = {
        "generated_at": now_iso(),
        "wiki_count": len(wiki_files),
        "orphans": orphans,
        "thin_articles": thin,
        "broken_links": broken_links,
    }
    out = REPORTS / f"lint-{datetime.now().strftime('%Y%m%dT%H%M%S')}.json"
    dump_json(out, payload)
    return str(out)
