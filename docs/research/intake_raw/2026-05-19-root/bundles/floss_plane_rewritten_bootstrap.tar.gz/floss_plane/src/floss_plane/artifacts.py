from __future__ import annotations
from pathlib import Path
from .util import sha256_text, now_iso


def register_artifact(conn, path: Path, layer: str, text: str, parent_sha256: str | None = None) -> str:
    digest = sha256_text(text)
    conn.execute(
        """
        INSERT INTO artifacts(path, layer, sha256, updated_at, parent_sha256)
        VALUES(?, ?, ?, ?, ?)
        ON CONFLICT(path) DO UPDATE SET
            layer=excluded.layer,
            sha256=excluded.sha256,
            updated_at=excluded.updated_at,
            parent_sha256=excluded.parent_sha256
        """,
        (str(path), layer, digest, now_iso(), parent_sha256),
    )
    conn.commit()
    return digest
