from pathlib import Path
import os

ROOT = Path(os.environ.get("FLOSS_PLANE_ROOT", Path(__file__).resolve().parents[2]))
DATA = ROOT / "data"
RAW = DATA / "raw"
PARSED = DATA / "parsed"
WIKI = DATA / "wiki"
GRAPH = DATA / "graph"
RUNTIME = DATA / "runtime"
REPORTS = RUNTIME / "reports"
LEASES = RUNTIME / "leases"
QUEUES = RUNTIME / "queues"
REFLECTIONS = RUNTIME / "reflections"
CONTINUITY = RUNTIME / "continuity"
DB = RUNTIME / "plane.db"
