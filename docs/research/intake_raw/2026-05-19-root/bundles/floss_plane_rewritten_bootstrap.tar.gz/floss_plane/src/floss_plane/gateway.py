from __future__ import annotations
import json


def schema() -> dict:
    return {
        "server": "floss-plane-local-gateway",
        "resources": [
            {"name": "wiki-index", "path": "data/wiki/index.md", "description": "Compressed vault catalog"},
            {"name": "continuity-latest", "path": "runtime/continuity/latest", "description": "Most recent continuity vector"},
            {"name": "reports-latest", "path": "data/runtime/reports", "description": "Latest lint and reflect outputs"},
        ],
        "tools": [
            {"name": "ingest", "description": "Ingest immutable raw evidence from a directory"},
            {"name": "compile", "description": "Compile raw evidence into parsed and wiki projections"},
            {"name": "add_claim", "description": "Persist a provenance-tracked claim"},
            {"name": "invalidate_claim", "description": "Invalidate a claim without destructive deletion"},
            {"name": "create_task", "description": "Create a coordination task with optional RU cost"},
            {"name": "claim_task", "description": "Lease a task to an agent or operator"},
            {"name": "lint", "description": "Run topology and article health checks"},
            {"name": "reflect", "description": "Generate asynchronous synthesis backlog and stats"},
            {"name": "save_continuity", "description": "Persist an n+1 continuity payload"},
        ],
        "prompts": [
            {"name": "bootstrap-agent", "description": "Load L0, open tasks, and latest continuity vector"}
        ],
    }


def schema_json() -> str:
    return json.dumps(schema(), indent=2)
