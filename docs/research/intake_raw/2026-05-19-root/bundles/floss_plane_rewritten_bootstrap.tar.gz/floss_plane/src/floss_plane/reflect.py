from __future__ import annotations
from .config import REPORTS
from .util import now_iso, dump_json
from datetime import datetime


def run_reflect(conn) -> str:
    claim_stats = {row[0]: row[1] for row in conn.execute("SELECT status, COUNT(*) FROM claims GROUP BY status")}
    task_stats = {row[0]: row[1] for row in conn.execute("SELECT status, COUNT(*) FROM tasks GROUP BY status")}
    payload = {
        "generated_at": now_iso(),
        "claim_stats": claim_stats,
        "task_stats": task_stats,
        "recommended_backlog": [
            "Generate L0 compressed context projection from index and open tasks",
            "Generate L1 topic projections for frequently referenced wiki pages",
            "Review superseded or contested claims with newest evidence",
            "Merge near-duplicate entities and alias pages",
            "Promote continuity vector payload into next-session bootstrap context",
        ],
    }
    out = REPORTS / f"reflect-{datetime.now().strftime('%Y%m%dT%H%M%S')}.json"
    dump_json(out, payload)
    return str(out)
