from __future__ import annotations
from .util import now_iso


def create_task(conn, title: str, capability: str | None = None, ru_cost: float = 0.0, blocked_by: str | None = None) -> int:
    cur = conn.execute(
        """
        INSERT INTO tasks(title, status, capability, lease_owner, lease_expires_at, ru_cost, blocked_by, created_at, updated_at)
        VALUES (?, 'open', ?, NULL, NULL, ?, ?, ?, ?)
        """,
        (title, capability, ru_cost, blocked_by, now_iso(), now_iso()),
    )
    conn.commit()
    return int(cur.lastrowid)


def claim_task(conn, task_id: int, owner: str, lease_expires_at: str | None = None) -> None:
    conn.execute(
        "UPDATE tasks SET status='claimed', lease_owner=?, lease_expires_at=?, updated_at=? WHERE id=?",
        (owner, lease_expires_at, now_iso(), task_id),
    )
    conn.commit()


def list_tasks(conn):
    return conn.execute("SELECT * FROM tasks ORDER BY id ASC").fetchall()
