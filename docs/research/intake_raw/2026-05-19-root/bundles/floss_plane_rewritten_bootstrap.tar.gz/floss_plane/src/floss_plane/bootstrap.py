from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

REQUIRED_FILES = {
    "index": "INDEX.md",
    "claude": "CLAUDE.md",
    "agents": "AGENTS.md",
    "context_surface": "shared-context-surface.json",
    "hook_surface": "shared-hook-surface.json",
    "skill_surface": "shared-skill-surface.json",
    "agent_surface": "shared-agent-surface.json",
}


class BootstrapError(RuntimeError):
    pass


class WorkspaceBootstrap:
    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace).expanduser().resolve()
        self.runtime = self.workspace / 'runtime'
        self.agent_surface_dir = self.workspace / '.agent-surface' / 'context'

    def resolve_paths(self) -> dict[str, Path]:
        return {k: self.workspace / rel for k, rel in REQUIRED_FILES.items()}

    def load(self) -> dict[str, Any]:
        paths = self.resolve_paths()
        missing = [k for k, p in paths.items() if not p.exists()]
        if missing:
            raise BootstrapError(f"Missing required bootstrap files: {', '.join(missing)}")
        docs = {k: paths[k].read_text(encoding='utf-8') for k in ('index', 'claude', 'agents')}
        surfaces = {k: json.loads(paths[k].read_text(encoding='utf-8')) for k in ('context_surface', 'hook_surface', 'skill_surface', 'agent_surface')}
        manifest = {
            'workspace': str(self.workspace),
            'documents': {k: {'path': str(paths[k]), 'chars': len(v)} for k, v in docs.items()},
            'surfaces': {k: {'path': str(paths[k]), 'manifest_version': surfaces[k].get('manifest_version')} for k in surfaces},
            'route_order': surfaces['context_surface'].get('default_route_order', []),
            'corpora': surfaces['context_surface'].get('corpora', []),
            'context_view_outputs': surfaces['context_surface'].get('context_views', {}).get('outputs', {}),
            'hook_targets': surfaces['hook_surface'].get('targets', {}),
            'skill_targets': surfaces['skill_surface'].get('targets', {}),
            'agent_targets': surfaces['agent_surface'].get('targets', {}),
            'rules': {
                'context': surfaces['context_surface'].get('rules', []),
                'hooks': surfaces['hook_surface'].get('rules', []),
                'skills': surfaces['skill_surface'].get('rules', []),
                'agents': surfaces['agent_surface'].get('rules', []),
            },
        }
        return {'paths': paths, 'docs': docs, 'surfaces': surfaces, 'manifest': manifest}

    def export_manifest(self, manifest: dict[str, Any]) -> Path:
        self.runtime.mkdir(parents=True, exist_ok=True)
        out = self.runtime / 'bootstrap_manifest.json'
        out.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        return out

    def init_runtime(self) -> dict[str, Any]:
        loaded = self.load()
        self.runtime.mkdir(parents=True, exist_ok=True)
        self.agent_surface_dir.mkdir(parents=True, exist_ok=True)
        db_path = self.runtime / 'floss_plane.db'
        conn = sqlite3.connect(db_path)
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS bootstrap_documents (
                key TEXT PRIMARY KEY,
                path TEXT NOT NULL,
                chars INTEGER NOT NULL,
                loaded_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS bootstrap_surfaces (
                key TEXT PRIMARY KEY,
                path TEXT NOT NULL,
                manifest_version TEXT,
                loaded_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS corpora (
                id TEXT PRIMARY KEY,
                uri TEXT,
                tier TEXT,
                priority INTEGER,
                summary TEXT,
                roots_json TEXT,
                keywords_json TEXT
            );
            """
        )
        for key, meta in loaded['manifest']['documents'].items():
            conn.execute('REPLACE INTO bootstrap_documents(key, path, chars) VALUES (?, ?, ?)', (key, meta['path'], meta['chars']))
        for key, meta in loaded['manifest']['surfaces'].items():
            conn.execute('REPLACE INTO bootstrap_surfaces(key, path, manifest_version) VALUES (?, ?, ?)', (key, meta['path'], meta['manifest_version']))
        for corpus in loaded['manifest']['corpora']:
            conn.execute(
                'REPLACE INTO corpora(id, uri, tier, priority, summary, roots_json, keywords_json) VALUES (?, ?, ?, ?, ?, ?, ?)',
                (
                    corpus.get('id'), corpus.get('uri'), corpus.get('tier'), corpus.get('priority'), corpus.get('summary'),
                    json.dumps(corpus.get('roots', [])), json.dumps(corpus.get('keywords', []))
                )
            )
        conn.commit()
        conn.close()
        self.export_manifest(loaded['manifest'])
        return {'db_path': str(db_path), 'manifest_path': str(self.runtime / 'bootstrap_manifest.json')}

    def build_context_views(self) -> dict[str, str]:
        loaded = self.load()
        ctx = loaded['surfaces']['context_surface']
        outputs = ctx.get('context_views', {}).get('outputs', {})
        sources = ctx.get('context_views', {}).get('sources', [])
        registry_path = self.workspace / outputs.get('registry', '.agent-surface/context/context-view-registry.json')
        l0_path = self.workspace / outputs.get('l0', '.agent-surface/context/CONTEXT_L0.md')
        l1_path = self.workspace / outputs.get('l1', '.agent-surface/context/CONTEXT_L1.md')
        registry_path.parent.mkdir(parents=True, exist_ok=True)
        reg, l0, l1 = [], ['# CONTEXT_L0', ''], ['# CONTEXT_L1', '']
        for src in sources:
            p = self.workspace / src['path']
            text = p.read_text(encoding='utf-8', errors='ignore') if p.exists() else ''
            compact = ' '.join(line.strip() for line in text.splitlines() if line.strip())
            summary = compact[: int(src.get('summary_chars', 220))].strip()
            reg.append({'id': src['id'], 'label': src['label'], 'path': src['path'], 'exists': p.exists(), 'summary': summary})
            l0.append(f"- **{src['label']}** (`{src['path']}`): {summary}")
            l1.extend([f"## {src['label']}", f"Path: `{src['path']}`", '', summary, ''])
        registry_path.write_text(json.dumps(reg, indent=2), encoding='utf-8')
        l0_path.write_text('\n'.join(l0) + '\n', encoding='utf-8')
        l1_path.write_text('\n'.join(l1) + '\n', encoding='utf-8')
        return {'registry': str(registry_path), 'l0': str(l0_path), 'l1': str(l1_path)}

    def route_query(self, query: str) -> list[dict[str, Any]]:
        corpora = self.load()['surfaces']['context_surface'].get('corpora', [])
        q = query.lower()
        ranked = []
        for corpus in corpora:
            score = int(corpus.get('priority', 0))
            for kw in corpus.get('keywords', []):
                if kw.lower() in q:
                    score += 5
            ranked.append({'id': corpus.get('id'), 'tier': corpus.get('tier'), 'priority': corpus.get('priority'), 'summary': corpus.get('summary'), 'roots': corpus.get('roots', []), 'score': score})
        return sorted(ranked, key=lambda x: x['score'], reverse=True)

    def gateway_schema(self) -> dict[str, Any]:
        loaded = self.load()
        return {
            'name': 'floss-plane-gateway',
            'workspace_id': loaded['surfaces']['context_surface'].get('workspace_id'),
            'route_order': loaded['manifest']['route_order'],
            'corpora': [{'id': c.get('id'), 'tier': c.get('tier'), 'roots': c.get('roots', [])} for c in loaded['manifest']['corpora']],
            'agent_targets': loaded['manifest']['agent_targets'],
            'hook_targets': loaded['manifest']['hook_targets'],
            'skill_targets': loaded['manifest']['skill_targets'],
        }
