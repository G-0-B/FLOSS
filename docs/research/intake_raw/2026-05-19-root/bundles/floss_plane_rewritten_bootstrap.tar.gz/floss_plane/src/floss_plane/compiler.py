from __future__ import annotations
from .config import RAW, PARSED, WIKI
from .util import load_text, now_iso
from .artifacts import register_artifact


def compile_all(conn) -> int:
    compiled = 0
    index_lines = ["# Index", ""]
    for file in sorted(RAW.glob("*")):
        if not file.is_file():
            continue
        raw_text = load_text(file)
        raw_sha = register_artifact(conn, file, "raw", raw_text)
        summary = " ".join(raw_text.split())[:400] if raw_text.strip() else "Empty source file."
        parsed_text = f"---\nsource: {file.name}\ncompiled_at: {now_iso()}\n---\n\n{summary}\n"
        parsed_path = PARSED / f"{file.stem}.md"
        parsed_path.write_text(parsed_text, encoding="utf-8")
        parsed_sha = register_artifact(conn, parsed_path, "parsed", parsed_text, raw_sha)
        wiki_text = (
            f"---\n"
            f"title: {file.stem}\n"
            f"type: source-note\n"
            f"source: {file.name}\n"
            f"compiled_at: {now_iso()}\n"
            f"source_hash: {raw_sha}\n"
            f"---\n\n"
            f"# {file.stem}\n\n"
            f"## Summary\n\n{summary}\n\n"
            f"## Provenance\n\n- Raw source: `{file.name}`\n- Raw hash: `{raw_sha}`\n"
        )
        wiki_path = WIKI / f"{file.stem}.md"
        wiki_path.write_text(wiki_text, encoding="utf-8")
        register_artifact(conn, wiki_path, "wiki", wiki_text, parsed_sha)
        index_lines.append(f"- [[{file.stem}]]: {summary[:140]}")
        compiled += 1
    index_text = "\n".join(index_lines) + "\n"
    index_path = WIKI / "index.md"
    index_path.write_text(index_text, encoding="utf-8")
    register_artifact(conn, index_path, "wiki", index_text)
    return compiled
