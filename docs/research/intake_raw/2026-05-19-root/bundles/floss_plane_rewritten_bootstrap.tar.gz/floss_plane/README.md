# floss-plane v0.2.0

This rewrite makes the local plane consume the real FLOSSI0ULLK bootstrap and routing surfaces instead of generic defaults.

## Bootstrap inputs

- `INDEX.md`
- `CLAUDE.md`
- `AGENTS.md`
- `shared-context-surface.json`
- `shared-hook-surface.json`
- `shared-skill-surface.json`
- `shared-agent-surface.json`

## Commands

```bash
floss-plane init --workspace /home/user
floss-plane bootstrap-status --workspace /home/user
floss-plane build-context --workspace /home/user
floss-plane route --workspace /home/user --query "hooks and canon routing"
floss-plane gateway-schema --workspace /home/user
```
