from pathlib import Path
from floss_plane.bootstrap import WorkspaceBootstrap


def test_manifest_loads():
    boot = WorkspaceBootstrap(Path('/home/user'))
    loaded = boot.load()
    assert loaded['manifest']['route_order']
    assert 'documents' in loaded['manifest']
    assert 'surfaces' in loaded['manifest']
