from __future__ import annotations
import argparse
from pathlib import Path
from .db import connect, ensure_dirs
from .ingest import ingest_dir
from .compiler import compile_all
from .models import Claim
from .claims import add_claim, invalidate_claim
from .tasks import create_task, claim_task, list_tasks
from .continuity import save_continuity, latest_continuity
from .lint import run_lint
from .reflect import run_reflect
from .gateway import schema_json


def main() -> None:
    parser = argparse.ArgumentParser(description="FLOSSIOULLK local Python plane")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init")

    p_ingest = sub.add_parser("ingest")
    p_ingest.add_argument("source_dir")

    sub.add_parser("compile")

    p_claim = sub.add_parser("add-claim")
    p_claim.add_argument("subject")
    p_claim.add_argument("predicate")
    p_claim.add_argument("object")
    p_claim.add_argument("source_ref")
    p_claim.add_argument("--confidence", type=float, default=0.5)
    p_claim.add_argument("--status", default="candidate")

    p_invalidate = sub.add_parser("invalidate-claim")
    p_invalidate.add_argument("claim_id", type=int)
    p_invalidate.add_argument("timestamp")

    p_task = sub.add_parser("create-task")
    p_task.add_argument("title")
    p_task.add_argument("--capability")
    p_task.add_argument("--ru-cost", type=float, default=0.0)
    p_task.add_argument("--blocked-by")

    p_claim_task = sub.add_parser("claim-task")
    p_claim_task.add_argument("task_id", type=int)
    p_claim_task.add_argument("owner")
    p_claim_task.add_argument("--lease-expires-at")

    sub.add_parser("list-tasks")
    sub.add_parser("lint")
    sub.add_parser("reflect")

    p_cont = sub.add_parser("save-continuity")
    p_cont.add_argument("perceptual_shift")
    p_cont.add_argument("trajectory_next")
    p_cont.add_argument("--substrate-anchor")

    sub.add_parser("latest-continuity")
    sub.add_parser("gateway-schema")

    args = parser.parse_args()
    conn = connect()

    if args.cmd == "init":
        ensure_dirs()
        print("initialized")
    elif args.cmd == "ingest":
        print(ingest_dir(conn, Path(args.source_dir)))
    elif args.cmd == "compile":
        print(compile_all(conn))
    elif args.cmd == "add-claim":
        cid = add_claim(conn, Claim(
            subject=args.subject,
            predicate=args.predicate,
            object=args.object,
            source_ref=args.source_ref,
            confidence=args.confidence,
            status=args.status,
        ))
        print(cid)
    elif args.cmd == "invalidate-claim":
        invalidate_claim(conn, args.claim_id, args.timestamp)
        print("ok")
    elif args.cmd == "create-task":
        print(create_task(conn, args.title, args.capability, args.ru_cost, args.blocked_by))
    elif args.cmd == "claim-task":
        claim_task(conn, args.task_id, args.owner, args.lease_expires_at)
        print("ok")
    elif args.cmd == "list-tasks":
        for row in list_tasks(conn):
            print(dict(row))
    elif args.cmd == "lint":
        print(run_lint())
    elif args.cmd == "reflect":
        print(run_reflect(conn))
    elif args.cmd == "save-continuity":
        print(save_continuity(conn, args.perceptual_shift, args.trajectory_next, args.substrate_anchor))
    elif args.cmd == "latest-continuity":
        row = latest_continuity(conn)
        print(dict(row) if row else {})
    elif args.cmd == "gateway-schema":
        print(schema_json())


if __name__ == "__main__":
    main()
