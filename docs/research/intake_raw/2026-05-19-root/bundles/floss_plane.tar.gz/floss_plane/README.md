# FLOSS Plane

A local-first Python orchestration plane for FLOSSIOULLK.

## Features

- Immutable raw evidence ingestion
- Parsed and wiki projection layers
- SQLite-backed claims, tasks, continuity vectors, and artifacts
- Lint and reflect reports
- Small local MCP-style JSON gateway
- Single-machine working skeleton for later Holochain / AD4M bridging

## Quick start

```bash
cd output/floss_plane
python -m floss_plane.cli init
python -m floss_plane.cli ingest ./data/raw
python -m floss_plane.cli compile
python -m floss_plane.cli lint
python -m floss_plane.cli reflect
python -m floss_plane.cli gateway-schema
```
